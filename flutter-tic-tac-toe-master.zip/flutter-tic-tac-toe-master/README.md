# flutter_tic_tac_toe

Tic-tac-toe implementation in Flutter.

## Build

```
git clone https://github.com/dmilicic/flutter-tic-tac-toe
flutter run
```

For help getting started with Flutter, view our 
[online documentation](https://flutter.io/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.

## License

`MIT`
